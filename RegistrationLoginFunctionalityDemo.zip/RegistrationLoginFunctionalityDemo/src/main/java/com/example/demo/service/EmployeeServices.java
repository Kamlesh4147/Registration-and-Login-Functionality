package com.example.demo.service;

import com.example.demo.dto.Employeedto;
import com.example.demo.dto.Logindto;
import com.example.demo.payloadresponse.LoginMessage;

public interface EmployeeServices {

	String addEmployee(Employeedto employeedto);

	LoginMessage loginEmployee(Logindto logindto);

}
