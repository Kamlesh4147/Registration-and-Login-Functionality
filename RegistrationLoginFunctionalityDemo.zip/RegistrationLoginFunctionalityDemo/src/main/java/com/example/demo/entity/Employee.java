package com.example.demo.entity;

import jakarta.persistence.Column;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {

	@jakarta.persistence.Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Employee_Id")
	private int EmployeeId;
	
	@Column(name="Employee_Name")
	private String EmployeeName;
	
	@Column(name="Employee_Email")
	private String email;
	
	@Column(name="Employee_Password")
	private String password;

	public Employee() {
		super();
	}

	

	public Employee(int employeeId, String employeeName, String email, String password) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		this.email = email;
		this.password = password;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		password = password;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", Email=" + email
				+ ", Password=" + password + "]";
	}
	
	
}
