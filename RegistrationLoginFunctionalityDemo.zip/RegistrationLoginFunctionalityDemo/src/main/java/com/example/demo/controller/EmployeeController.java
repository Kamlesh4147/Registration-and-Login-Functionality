package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Employeedto;
import com.example.demo.dto.Logindto;
import com.example.demo.entity.Employee;
import com.example.demo.payloadresponse.LoginMessage;
import com.example.demo.service.EmployeeServices;

@RestController
@CrossOrigin
@RequestMapping("api/v1/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeServices employeeservice;
	
	
	@PostMapping("/save")
	public String saveEmployee(@RequestBody Employeedto employeedto) {
		
		String id= employeeservice.addEmployee(employeedto);
		return id;
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> loginEmployee(@RequestBody Logindto logindto){
		
		LoginMessage loginMessage= employeeservice.loginEmployee(logindto);
		
		return ResponseEntity.ok(loginMessage);
		
	}
}
