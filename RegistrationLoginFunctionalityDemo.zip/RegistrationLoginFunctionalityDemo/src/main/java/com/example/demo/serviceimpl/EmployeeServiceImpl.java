package com.example.demo.serviceimpl;


import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dto.Employeedto;
import com.example.demo.dto.Logindto;
import com.example.demo.entity.Employee;
import com.example.demo.payloadresponse.LoginMessage;
import com.example.demo.repo.EmployeeRepository;
import com.example.demo.service.EmployeeServices;


@Service
public class EmployeeServiceImpl implements EmployeeServices{
	
	@Autowired
	private EmployeeRepository employeeRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public String addEmployee(Employeedto employeedto) {
		
		  if (employeedto.getPassword() == null) {
	            throw new IllegalArgumentException("Password cannot be null");
	        }
		
		Employee employee= new Employee(
				employeedto.getEmployeeId(),
				employeedto.getEmployeeName(),
				employeedto.getEmail(),
				this.passwordEncoder.encode(employeedto.getPassword())
					
				);

		employeeRepo.save(employee);
		
		return employee.getEmployeeName();
	}

	@Override
	public LoginMessage loginEmployee(Logindto logindto) {
		String msg=" ";
		Employee Employee1 = employeeRepo.findByEmail(logindto.getEmail());
		
		if(Employee1 !=null) {
			
			String password = logindto.getPassword();
			String encodedpassword = Employee1.getPassword();
			
			boolean isPassRyt = passwordEncoder.matches(password, encodedpassword);
			
			if(isPassRyt) {
				Optional<Employee> employee = employeeRepo.findOneByEmailAndPassword(logindto.getEmail(), encodedpassword);
			if(employee.isPresent()) {
				
				return new LoginMessage("Login Successful..", true);
			}else {
				return new LoginMessage("Login Failed", false);
			}
			}else {
				return new LoginMessage("Inccorrect Password..", false);
			}
		}else {
			return new LoginMessage("Email Does Not Exist", false);
		}
	
	}

}
